using Microsoft.Ccr.Core;
using Microsoft.Dss.Core.DsspHttp;
using Microsoft.Dss.Core.Attributes;
using Microsoft.Dss.ServiceModel.Dssp;

using System;
using System.Collections.Generic;
using System.Collections;
using W3C.Soap;

using nativePhidgets = Phidgets;

namespace Phidgets.Robotics.Services
{
    public static class Contract
    {
        // TT - Remove uppercase characters
        public const string Identifier = "http://schemas.phidgets.com/2006/08/phidgetcommon.html";
    }

    [DataContract]
    public class DigitalInputInfo
    {
        [DataMember]
        public bool? State;
    }

    [DataContract]
    public class DigitalOutputInfo
    {
        [DataMember]
        public bool? State;
    }

    /// <summary>
    /// A Phidget
    /// </summary>
    [DataContract]
    public class PhidgetDeviceInfo
    {
        private string _type, _name, _label;
        private long? _serialNumber;
        private long? _version;
        private bool? _attached;

        public PhidgetDeviceInfo()
        {
            this._type = "<Uninitialized>";
            this._name = null;
            this._label = null;
            this._serialNumber = null;
            this._version = null;
            this._attached = false;
        }

        public PhidgetDeviceInfo(Phidgets.Phidget device)
        {
            this._type = device.Type;
            this._name = device.Name;
            this._serialNumber = device.SerialNumber;
            this._attached = device.Attached;
            if (device.Attached)
            {
                this._label = device.Label;
                this._version = device.Version;
            }
            else
            {
                this._label = null;
                this._version = null;
            }
            if (this._serialNumber == -1) _serialNumber = null;
        }

        /// <summary>
        /// Phidget type
        /// </summary>
        [DataMember]
        public string Type
        {
            get { return this._type; }
            set { this._type = value; }
        }
        /// <summary>
        /// Phidget Name
        /// </summary>
        [DataMember]
        public string Name
        {
            get { return this._name; }
            set { this._name = value; }
        }
        /// <summary>
        /// Phidget Label
        /// </summary>
        [DataMember]
        public string Label
        {
            get { return this._label; }
            set { this._label = value; }
        }
        /// <summary>
        /// Phidget Serial Number
        /// </summary>
        [DataMember]
        public long? SerialNumber
        {
            get { return this._serialNumber; }
            set { this._serialNumber = value; }
        }
        /// <summary>
        /// Phidget Version Number
        /// </summary>
        [DataMember]
        public long? Version
        {
            get { return this._version; }
            set { this._version = value; }
        }
        /// <summary>
        /// Attached or not status
        /// </summary>
        [DataMember]
        public bool? Attached
        {
            get { return this._attached; }
            set { this._attached = value; }
        }
    }
}
